#ifndef __GET_AVG_OF_VECTOR_H__
#define __GET_AVG_OF_VECTOR_H__

#include <vector>

float get_avg_of_vector(const std::vector<int> &);

#endif
