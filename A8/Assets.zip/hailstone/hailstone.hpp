#ifndef __HAILSTONE_H__
#define __HAILSTONE_H__

bool satisfies_hailstone(unsigned long long);

#endif
