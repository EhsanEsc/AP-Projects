
make clean
