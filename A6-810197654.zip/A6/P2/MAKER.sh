
make
./2.out
read -p "PRESSS!!!!"
