make clean
read -p "press....."
