
make
./1.out
read -p "Press..."
