
make
./3.out
read -p "#########"
